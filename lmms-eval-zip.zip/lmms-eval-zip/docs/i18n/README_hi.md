<p align="center" width="70%">
<img src="https://i.postimg.cc/KvkLzbF9/WX20241212-014400-2x.png">
</p>

# बड़े मल्टीमॉडल मॉडल मूल्यांकन सूट

🌐 [English](../../README.md) | [简体中文](README_zh-CN.md) | [繁體中文](README_zh-TW.md) | [日本語](README_ja.md) | [한국어](README_ko.md) | [Español](README_es.md) | [Français](README_fr.md) | [Deutsch](README_de.md) | [Português](README_pt-BR.md) | [Русский](README_ru.md) | [Italiano](README_it.md) | [Nederlands](README_nl.md) | [Polski](README_pl.md) | [Türkçe](README_tr.md) | [العربية](README_ar.md) | **हिन्दी** | [Tiếng Việt](README_vi.md) | [Indonesia](README_id.md)

[![PyPI](https://img.shields.io/pypi/v/lmms-eval)](https://pypi.org/project/lmms-eval)
![PyPI - Downloads](https://img.shields.io/pypi/dm/lmms-eval)
[![GitHub contributors](https://img.shields.io/github/contributors/EvolvingLMMs-Lab/lmms-eval)](https://github.com/EvolvingLMMs-Lab/lmms-eval/graphs/contributors)
[![issue resolution](https://img.shields.io/github/issues-closed-raw/EvolvingLMMs-Lab/lmms-eval)](https://github.com/EvolvingLMMs-Lab/lmms-eval/issues)
[![open issues](https://img.shields.io/github/issues-raw/EvolvingLMMs-Lab/lmms-eval)](https://github.com/EvolvingLMMs-Lab/lmms-eval/issues)

> `lmms-eval` के साथ बड़े मल्टीमॉडल मॉडल (LMMs) के विकास को तेज करें। हम अधिकांश टेक्स्ट, इमेज, वीडियो और ऑडियो कार्यों का समर्थन करते हैं।

🏠 [LMMs-Lab होमपेज](https://www.lmms-lab.com/) | 🤗 [Huggingface डेटासेट](https://huggingface.co/lmms-lab) | <a href="https://emoji.gg/emoji/1684-discord-thread"><img src="https://cdn3.emoji.gg/emojis/1684-discord-thread.png" width="14px" height="14px" alt="Discord_Thread"></a> [discord/lmms-eval](https://discord.gg/zdkwKUqrPy)

📖 [समर्थित कार्य (100+)](https://github.com/EvolvingLMMs-Lab/lmms-eval/blob/main/docs/current_tasks.md) | 🌟 [समर्थित मॉडल (30+)](https://github.com/EvolvingLMMs-Lab/lmms-eval/tree/main/lmms_eval/models) | 📚 [दस्तावेज़ीकरण](../README.md)

---

## घोषणाएं

- [2025-10] 🚀🚀 **LMMs-Eval v0.5** यहां है! यह प्रमुख रिलीज़ व्यापक ऑडियो मूल्यांकन, रिस्पॉन्स कैशिंग, 5 नए मॉडल (GPT-4o Audio Preview, Gemma-3, LongViLA-R1, LLaVA-OneVision 1.5, Thyme), और 50+ नए बेंचमार्क वेरिएंट पेश करती है जो ऑडियो (Step2, VoiceBench, WenetSpeech), विज़न (CharXiv, Lemonade), और रीज़निंग (CSBench, SciBench, MedQA, SuperGPQA) को कवर करते हैं। विवरण के लिए [रिलीज़ नोट्स](https://github.com/EvolvingLMMs-Lab/lmms-eval/blob/main/docs/lmms-eval-0.5.md) देखें।
- [2025-07] 🚀🚀 हमने `lmms-eval-0.4` जारी किया है। अधिक विवरण के लिए [रिलीज़ नोट्स](https://github.com/EvolvingLMMs-Lab/lmms-eval/blob/main/docs/lmms-eval-0.4.md) देखें।

## `lmms-eval` क्यों?

हम आर्टिफिशियल जनरल इंटेलिजेंस (AGI) बनाने की दिशा में एक रोमांचक यात्रा पर हैं, जैसे 1960 के दशक में चंद्रमा पर उतरने का उत्साह था। यह यात्रा उन्नत बड़े भाषा मॉडल (LLMs) और बड़े मल्टीमॉडल मॉडल (LMMs) द्वारा संचालित है, जो जटिल प्रणालियां हैं जो विभिन्न प्रकार के मानव कार्यों को समझने, सीखने और करने में सक्षम हैं।

यह मापने के लिए कि ये मॉडल कितने उन्नत हैं, हम विभिन्न मूल्यांकन बेंचमार्क का उपयोग करते हैं। ये बेंचमार्क ऐसे उपकरण हैं जो हमें इन मॉडलों की क्षमताओं को समझने में मदद करते हैं, और हमें दिखाते हैं कि हम AGI प्राप्त करने के कितने करीब हैं। हालांकि, इन बेंचमार्क को खोजना और उपयोग करना एक बड़ी चुनौती है।

भाषा मॉडल के क्षेत्र में, [lm-evaluation-harness](https://github.com/EleutherAI/lm-evaluation-harness) के काम ने एक मूल्यवान मिसाल कायम की है। हमने lm-evaluation-harness के उत्कृष्ट और कुशल डिज़ाइन को अपनाया और LMM के सुसंगत और कुशल मूल्यांकन के लिए सावधानीपूर्वक तैयार किया गया मूल्यांकन फ्रेमवर्क **lmms-eval** पेश किया।

## स्थापना

### uv का उपयोग करना (सुसंगत वातावरण के लिए अनुशंसित)

हम पैकेज प्रबंधन के लिए `uv` का उपयोग करते हैं ताकि यह सुनिश्चित हो सके कि सभी डेवलपर्स बिल्कुल समान पैकेज संस्करणों का उपयोग करें। पहले, uv स्थापित करें:
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

सुसंगत वातावरण के साथ विकास के लिए:
```bash
git clone https://github.com/EvolvingLMMs-Lab/lmms-eval
cd lmms-eval
# अनुशंसित
uv pip install -e ".[all]"
# यदि आप uv sync का उपयोग करना चाहते हैं
# uv sync  # यह uv.lock से आपके वातावरण को बनाता/अपडेट करता है
```

कमांड चलाने के लिए:
```bash
uv run python -m lmms_eval --help  # uv run के साथ कोई भी कमांड चलाएं
```

### वैकल्पिक स्थापना

Git से सीधे उपयोग के लिए:
```bash
uv venv eval
uv venv --python 3.12
source eval/bin/activate
# यदि आप इस स्थापना का उपयोग करते हैं तो आपको अपना खुद का टास्क yaml जोड़ना और शामिल करना पड़ सकता है
uv pip install git+https://github.com/EvolvingLMMs-Lab/lmms-eval.git
```

## उपयोग

> अधिक उदाहरण [examples/models](../../examples/models) में देखें

**OpenAI संगत मॉडल का मूल्यांकन**

```bash
bash examples/models/openai_compatible.sh
bash examples/models/xai_grok.sh
```

**vLLM का मूल्यांकन**

```bash
bash examples/models/vllm_qwen2vl.sh
```

**LLaVA-OneVision का मूल्यांकन**

```bash
bash examples/models/llava_onevision.sh
```

**अधिक पैरामीटर**

```bash
python3 -m lmms_eval --help
```

## कस्टम मॉडल और डेटासेट जोड़ें

हमारा [दस्तावेज़ीकरण](../README.md) देखें।

## आभार

lmms_eval [lm-eval-harness](https://github.com/EleutherAI/lm-evaluation-harness) का एक फोर्क है। हम प्रासंगिक जानकारी के लिए lm-eval-harness के [दस्तावेज़ीकरण](https://github.com/EleutherAI/lm-evaluation-harness/tree/main/docs) को पढ़ने की सलाह देते हैं।

## उद्धरण

```shell
@misc{zhang2024lmmsevalrealitycheckevaluation,
      title={LMMs-Eval: Reality Check on the Evaluation of Large Multimodal Models}, 
      author={Kaichen Zhang and Bo Li and Peiyuan Zhang and Fanyi Pu and Joshua Adrian Cahyono and Kairui Hu and Shuai Liu and Yuanhan Zhang and Jingkang Yang and Chunyuan Li and Ziwei Liu},
      year={2024},
      eprint={2407.12772},
      archivePrefix={arXiv},
      primaryClass={cs.CL},
      url={https://arxiv.org/abs/2407.12772}, 
}
```
